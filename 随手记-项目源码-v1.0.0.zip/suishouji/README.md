# 随手记

一款轻量、离线优先的 Android 待办记事应用。写下、勾掉、删去，所有记录只留在这台设备。

![首页](screenshots/home-light.png)

| 空状态 | 深色模式 | 新增弹窗 |
| --- | --- | --- |
| ![空状态](screenshots/home-empty.png) | ![深色模式](screenshots/home-dark.png) | ![新增弹窗](screenshots/editor.png) |

## 功能

- **随手记**：首页悬浮按钮随时唤起底部输入面板，支持 1000 字、多行长文本。
- **勾选完成**：圆形勾选框带缩放反馈与轻触震动，完成后文字变灰、加删除线。
- **编辑 / 删除**：点击事项进入编辑；长按或点右侧菜单可编辑 / 删除；左滑也可删除。
- **误删可撤销**：删除单条、清空已完成都可在 Snackbar 中一键撤销。
- **清单管理**：全部 / 待办 / 已完成筛选，三种排序方式（未完成优先、最新创建、最早创建），排序偏好本地持久化。
- **完成进度**：首页卡片展示总览与环形完成度。
- **空状态引导**：不同筛选下显示对应插画和文案。
- **深色模式**：跟随系统切换暖色深色主题。
- **离线与隐私**：Room 本地数据库，无网络权限、无存储权限、关闭系统云备份。

## 技术栈

- Kotlin 2.2 + Jetpack Compose（Material 3）
- MVVM + Repository
- Room 2.8（KSP 生成 DAO 实现）
- Kotlin Coroutines + Flow
- AGP 9.5.1 / Gradle 9.6 / JDK 17+（实测 JDK 21）
- compileSdk 37 · targetSdk 36 · minSdk 26

## 项目结构

```text
app/src/main/java/com/suishouji/app/
├── data/                  # TodoEntity、TodoDao、AppDatabase、Repository、Settings
├── model/                 # 排序、筛选规则
├── ui/
│   ├── components/        # 列表项、空状态、编辑面板、清空确认框
│   ├── theme/             # 颜色、字体、形状、主题
│   ├── TodoApp.kt         # 应用壳、Snackbar、弹窗状态
│   ├── TodoScreen.kt      # 首页、头部、总览、列表、排序菜单
│   └── TodoViewModel.kt   # 页面状态与交互
└── util/                  # 中文相对时间格式化
```

## 构建

只有手机、没有电脑？可以按 [手机打包指南](手机打包指南.md) 用 GitHub Actions 云端生成 APK。

需要：

1. Android SDK Platform 37、Build-Tools 36.0.0；
2. JDK 17 或更高版本；
3. 在 `local.properties` 中写入 SDK 路径，或设置 `ANDROID_HOME`。

```bash
# Windows
gradlew.bat :app:assembleDebug

# macOS / Linux
./gradlew :app:assembleDebug
```

生成位置：`app/build/outputs/apk/debug/app-debug.apk`

> 项目路径含中文时，AGP 会触发路径检查；项目的 `gradle.properties` 已设置
> `android.overridePathCheck=true`。若你的环境仍对非 ASCII 路径敏感，建议将项目放到纯英文路径再构建。
>
> Gradle Wrapper 默认从腾讯云镜像下载 Gradle 9.6.0，SHA-256 与 Gradle 官方发行包一致；
> 如该镜像访问不畅，可把 `gradle/wrapper/gradle-wrapper.properties` 中的地址改回
> `https://services.gradle.org/distributions/gradle-9.6.0-bin.zip`。

## 测试

```bash
gradlew.bat :app:testDebugUnitTest
```

共 15 个测试，覆盖时间格式化、排序 / 筛选、真实 `MainActivity` 启动、新增事项、勾选完成，以及 Robolectric 原生图形截图。

> 注意：Windows 下如果项目位于含中文的路径，Gradle 的测试工作进程可能报
> `ClassNotFoundException: GradleWorkerMain`（AGP / Gradle Wrapper 的已知非 ASCII 路径问题）。
> 编译 APK 不受影响；如需运行测试，请把项目复制到纯英文路径后再执行。
> 本项目这 15 个测试已在纯英文副本中全部通过。

截图测试输出：`app/build/screenshots/`。

## 安装包

| 项目 | 值 |
| --- | --- |
| 文件 | `dist/随手记-v1.0.0.apk` |
| 包名 | `com.suishouji.app` |
| 版本 | 1.0.0 (1) |
| 体积 | 约 11.7 MB |
| SHA-256 | `67E3C066FBFEFDF335150142B55E224246BBFA842C245F321BC4DB2AC60312B2` |
| 签名 | Android Debug（APK Signature Scheme v2） |

```bash
adb install -r "dist/随手记-v1.0.0.apk"
```

`dist/随手记-v1.0.0.apk` 是已用 debug 密钥签名、可直接侧载安装的包。若要发布到应用商店，请用自己的发布密钥重新签名。

## 数据说明

- 数据库文件：`suishouji.db`（Room，表 `todo_table`）。
- `allowBackup=false`，不参与系统云备份，也不声明网络 / 存储权限。
- 卸载应用会删除全部本地记录。

## 后续可扩展

`TodoEntity` 已预留 `id / content / isCompleted / createTime / updateTime`。可以平滑增加：

- 分类标签：增加 `tag` 字段，DAO 增加分组查询；
- 提醒：增加 `remindTime`，配合 WorkManager / AlarmManager 与通知权限；
- 云同步：在 `TodoRepository` 增加远程数据源分支；
- 图片附件：新增附件表，以外键关联 `todo_table.id`；
- 导出 / 分享：从 Repository 读取全量数据生成文本。
