package com.suishouji.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.suishouji.app.data.TodoEntity
import com.suishouji.app.model.TodoFilter
import com.suishouji.app.model.TodoSort
import com.suishouji.app.ui.components.TodoEditorSheet
import com.suishouji.app.ui.theme.SuishoujiTheme
import org.junit.Assert.assertNotNull
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowDialog
import java.io.File

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36], qualifiers = "w412dp-h915dp-420dpi")
class TodoScreenshotTest {
    @get:Rule
    val composeRule = createComposeRule()

    private fun demoState(): TodoUiState {
        val now = System.currentTimeMillis()
        return TodoUiState(
            todos = listOf(
                TodoEntity(
                    id = 1,
                    content = "给阳台的绿萝浇水",
                    createTime = now - 45 * 60_000L,
                    updateTime = now - 45 * 60_000L,
                ),
                TodoEntity(
                    id = 2,
                    content = "把《人间草木》最后两章读完，顺手记下喜欢的句子。",
                    createTime = now - 3 * 60 * 60_000L,
                    updateTime = now - 3 * 60 * 60_000L,
                ),
                TodoEntity(
                    id = 3,
                    content = "预约周五下午的牙医",
                    createTime = now - 25 * 60 * 60_000L,
                    updateTime = now - 25 * 60 * 60_000L,
                ),
                TodoEntity(
                    id = 4,
                    content = "给妈妈回个电话",
                    isCompleted = true,
                    createTime = now - 5 * 60 * 60_000L,
                    updateTime = now - 60 * 60_000L,
                ),
            ),
            filter = TodoFilter.ALL,
            sort = TodoSort.PENDING_FIRST,
            isLoading = false,
        )
    }

    private fun capture(name: String) {
        composeRule.waitForIdle()
        val bitmap = composeRule.onRoot()
            .captureToImage()
            .asAndroidBitmap()
        val output = File(
            System.getProperty("user.dir"),
            "build/screenshots/$name.png",
        )
        output.parentFile?.mkdirs()
        output.outputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }
    }

    @Test
    fun captureHome() {
        composeRule.setContent {
            SuishoujiTheme(darkTheme = false) {
                TodoAppPreviewContent(demoState())
            }
        }
        capture("home-light")
    }

    @Test
    fun captureEmpty() {
        composeRule.setContent {
            SuishoujiTheme(darkTheme = false) {
                TodoAppPreviewContent(
                    TodoUiState(
                        filter = TodoFilter.ALL,
                        isLoading = false,
                    ),
                )
            }
        }
        capture("home-empty")
    }

    @Test
    fun captureDark() {
        composeRule.setContent {
            SuishoujiTheme(darkTheme = true) {
                TodoAppPreviewContent(demoState())
            }
        }
        capture("home-dark")
    }

    @Test
    fun captureEditor() {
        composeRule.setContent {
            SuishoujiTheme(darkTheme = false) {
                TodoEditorSheet(
                    initialTodo = null,
                    onDismiss = {},
                    onSave = {},
                )
            }
        }
        composeRule.waitForIdle()

        val dialog = ShadowDialog.getLatestDialog()
        assertNotNull(dialog)
        val view = requireNotNull(dialog.window?.decorView)
        val bitmap = Bitmap.createBitmap(
            view.width.coerceAtLeast(1),
            view.height.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888,
        )
        view.draw(Canvas(bitmap))
        val output = File(
            System.getProperty("user.dir"),
            "build/screenshots/editor.png",
        )
        output.parentFile?.mkdirs()
        output.outputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }
    }
}
