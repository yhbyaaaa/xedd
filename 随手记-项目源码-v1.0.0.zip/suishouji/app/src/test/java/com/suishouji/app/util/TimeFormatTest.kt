package com.suishouji.app.util

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class TimeFormatTest {
    private val zone = ZoneId.of("Asia/Shanghai")

    private fun epoch(
        year: Int,
        month: Int,
        day: Int,
        hour: Int,
        minute: Int,
    ): Long = ZonedDateTime.of(year, month, day, hour, minute, 0, 0, zone)
        .toInstant()
        .toEpochMilli()

    @Test
    fun `today uses time only`() {
        val now = epoch(2026, 11, 10, 21, 0)
        val created = epoch(2026, 11, 10, 9, 30)

        assertEquals("今天 09:30", formatTodoTime(created, now, zone))
    }

    @Test
    fun `yesterday is labelled`() {
        val now = epoch(2026, 11, 10, 21, 0)
        val created = epoch(2026, 11, 9, 22, 5)

        assertEquals("昨天 22:05", formatTodoTime(created, now, zone))
    }

    @Test
    fun `same year uses month and day`() {
        val now = epoch(2026, 11, 10, 21, 0)
        val created = epoch(2026, 11, 3, 8, 0)

        assertEquals("11月3日", formatTodoTime(created, now, zone))
    }

    @Test
    fun `other year uses full date`() {
        val now = epoch(2026, 11, 10, 21, 0)
        val created = epoch(2025, 12, 31, 23, 59)

        assertEquals("2025年12月31日", formatTodoTime(created, now, zone))
    }

    @Test
    fun `header date includes chinese weekday`() {
        val now = epoch(2026, 11, 10, 21, 0)

        assertEquals("11月10日 · 星期二", formatHeaderDate(now, zone))
    }

    @Test
    fun `greeting changes through the day`() {
        assertEquals("早上好", greetingForHour(7))
        assertEquals("上午好", greetingForHour(10))
        assertEquals("下午好", greetingForHour(15))
        assertEquals("晚上好", greetingForHour(21))
        assertEquals("夜深了", greetingForHour(2))
    }
}
