package com.suishouji.app.model

import com.suishouji.app.data.TodoEntity
import org.junit.Assert.assertEquals
import org.junit.Test

class TodoPreferencesTest {
    private val older = TodoEntity(
        id = 1,
        content = "买牛奶",
        createTime = 100,
        updateTime = 100,
    )
    private val newer = TodoEntity(
        id = 2,
        content = "给妈妈打电话",
        createTime = 200,
        updateTime = 200,
    )
    private val completed = TodoEntity(
        id = 3,
        content = "浇花",
        isCompleted = true,
        createTime = 300,
        updateTime = 300,
    )

    @Test
    fun `pending first keeps unfinished items ahead`() {
        val sorted = TodoSort.PENDING_FIRST.sort(listOf(completed, older, newer))

        assertEquals(listOf("给妈妈打电话", "买牛奶", "浇花"), sorted.map { it.content })
    }

    @Test
    fun `newest order ignores completion`() {
        val sorted = TodoSort.NEWEST_FIRST.sort(listOf(older, completed, newer))

        assertEquals(listOf("浇花", "给妈妈打电话", "买牛奶"), sorted.map { it.content })
    }

    @Test
    fun `oldest order ignores completion`() {
        val sorted = TodoSort.OLDEST_FIRST.sort(listOf(newer, completed, older))

        assertEquals(listOf("买牛奶", "给妈妈打电话", "浇花"), sorted.map { it.content })
    }

    @Test
    fun `filters split pending and completed`() {
        val all = listOf(older, completed, newer)

        assertEquals(3, TodoFilter.ALL.filter(all).size)
        assertEquals(listOf(1L, 2L), TodoFilter.PENDING.filter(all).map { it.id })
        assertEquals(listOf(3L), TodoFilter.COMPLETED.filter(all).map { it.id })
    }
}
