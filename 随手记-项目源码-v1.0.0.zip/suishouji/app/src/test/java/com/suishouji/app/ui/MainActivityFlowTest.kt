package com.suishouji.app.ui

import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.isToggleable
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.suishouji.app.MainActivity
import com.suishouji.app.SuishoujiApplication
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36], qualifiers = "w412dp-h915dp-420dpi")
class MainActivityFlowTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private val app: SuishoujiApplication
        get() = ApplicationProvider.getApplicationContext()

    @Before
    fun clearDatabase() {
        runBlocking {
            app.repository.todos.first().forEach { app.repository.delete(it) }
        }
        composeRule.waitForIdle()
    }

    @Test
    fun addTodoAndCheckItOff() {
        composeRule.onNodeWithTag("add-todo").performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("新的一笔").fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNode(hasSetTextAction()).performTextInput("明天买牛奶")
        composeRule.onNodeWithTag("save-todo")
            .assertIsEnabled()
            .performClick()

        composeRule.waitUntil(timeoutMillis = 5_000) {
            composeRule.onAllNodesWithText("明天买牛奶", useUnmergedTree = true)
                .fetchSemanticsNodes()
                .isNotEmpty()
        }
        composeRule.onNodeWithText("明天买牛奶", useUnmergedTree = true).assertExists()

        composeRule.onAllNodes(isToggleable())[0].performClick()
        composeRule.waitUntil(timeoutMillis = 5_000) {
            runBlocking {
                app.repository.todos.first().any { todo ->
                    todo.content == "明天买牛奶" && todo.isCompleted
                }
            }
        }

        composeRule.onNodeWithText("明天买牛奶", useUnmergedTree = true).assertExists()
    }
}
