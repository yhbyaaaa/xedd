package com.suishouji.app.util

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.SIMPLIFIED_CHINESE)
private val shortDateFormatter = DateTimeFormatter.ofPattern("M月d日", Locale.SIMPLIFIED_CHINESE)
private val fullDateFormatter = DateTimeFormatter.ofPattern("yyyy年M月d日", Locale.SIMPLIFIED_CHINESE)
private val headerFormatter = DateTimeFormatter.ofPattern("M月d日 · EEEE", Locale.SIMPLIFIED_CHINESE)

fun formatTodoTime(
    timestamp: Long,
    now: Long = System.currentTimeMillis(),
    zoneId: ZoneId = ZoneId.systemDefault(),
): String {
    val moment = Instant.ofEpochMilli(timestamp).atZone(zoneId)
    val today = Instant.ofEpochMilli(now).atZone(zoneId).toLocalDate()
    val date = moment.toLocalDate()
    val time = moment.format(timeFormatter)

    return when {
        date == today -> "今天 $time"
        date == today.minusDays(1) -> "昨天 $time"
        date.year == today.year -> date.format(shortDateFormatter)
        else -> date.format(fullDateFormatter)
    }
}

fun formatHeaderDate(
    now: Long = System.currentTimeMillis(),
    zoneId: ZoneId = ZoneId.systemDefault(),
): String = Instant.ofEpochMilli(now).atZone(zoneId).format(headerFormatter)

fun greetingForHour(hour: Int): String = when (hour) {
    in 5..8 -> "早上好"
    in 9..11 -> "上午好"
    in 12..13 -> "中午好"
    in 14..17 -> "下午好"
    in 18..22 -> "晚上好"
    else -> "夜深了"
}
