package com.suishouji.app.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.suishouji.app.data.TodoEntity
import com.suishouji.app.ui.components.ClearCompletedDialog
import com.suishouji.app.ui.components.TodoEditorSheet

private data class EditorRequest(val todo: TodoEntity?)

@Composable
fun TodoApp(viewModel: TodoViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    var editorRequest by remember { mutableStateOf<EditorRequest?>(null) }
    var showClearDialog by remember { mutableStateOf(false) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is TodoEvent.Deleted -> {
                    val result = snackbarHostState.showSnackbar(
                        message = "已删除这条记录",
                        actionLabel = "撤销",
                        duration = SnackbarDuration.Long,
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        viewModel.undoDelete(event.todo)
                    }
                }

                is TodoEvent.CompletedCleared -> {
                    val result = snackbarHostState.showSnackbar(
                        message = "已清空 ${event.todos.size} 件已完成事项",
                        actionLabel = "撤销",
                        duration = SnackbarDuration.Long,
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        viewModel.undoClearCompleted(event.todos)
                    }
                }

                is TodoEvent.Saved -> {
                    snackbarHostState.showSnackbar(
                        message = if (event.isNew) "已记下" else "修改已保存",
                        duration = SnackbarDuration.Short,
                    )
                }

                is TodoEvent.Failed -> {
                    snackbarHostState.showSnackbar(
                        message = event.message,
                        duration = SnackbarDuration.Short,
                    )
                }
            }
        }
    }

    TodoAppScaffold(
        state = state,
        snackbarHostState = snackbarHostState,
        onAdd = { editorRequest = EditorRequest(null) },
        onEdit = { editorRequest = EditorRequest(it) },
        onToggle = viewModel::toggleCompleted,
        onDelete = viewModel::deleteTodo,
        onFilterChange = viewModel::setFilter,
        onSortChange = viewModel::setSort,
        onClearCompleted = { showClearDialog = true },
    )

    editorRequest?.let { request ->
        TodoEditorSheet(
            initialTodo = request.todo,
            onDismiss = { editorRequest = null },
            onSave = { content ->
                viewModel.saveTodo(content, request.todo)
                editorRequest = null
            },
        )
    }

    if (showClearDialog) {
        ClearCompletedDialog(
            count = state.completedCount,
            onDismiss = { showClearDialog = false },
            onConfirm = {
                showClearDialog = false
                viewModel.clearCompleted()
            },
        )
    }
}

@Composable
fun TodoAppScaffold(
    state: TodoUiState,
    snackbarHostState: SnackbarHostState,
    onAdd: () -> Unit,
    onEdit: (TodoEntity) -> Unit,
    onToggle: (TodoEntity) -> Unit,
    onDelete: (TodoEntity) -> Unit,
    onFilterChange: (com.suishouji.app.model.TodoFilter) -> Unit,
    onSortChange: (com.suishouji.app.model.TodoSort) -> Unit,
    onClearCompleted: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        PaperBackdrop()
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = {
                SnackbarHost(snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        modifier = Modifier.padding(horizontal = 16.dp),
                        shape = RoundedCornerShape(16.dp),
                        containerColor = MaterialTheme.colorScheme.onSurface,
                        contentColor = MaterialTheme.colorScheme.surface,
                        actionColor = MaterialTheme.colorScheme.primaryContainer,
                    )
                }
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = onAdd,
                    modifier = Modifier.testTag("add-todo"),
                    icon = {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                        )
                    },
                    text = {
                        Text(
                            text = "记一笔",
                            style = MaterialTheme.typography.labelLarge,
                        )
                    },
                    shape = RoundedCornerShape(20.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                )
            },
        ) { innerPadding ->
            TodoScreen(
                state = state,
                onAdd = onAdd,
                onEdit = onEdit,
                onToggle = onToggle,
                onDelete = onDelete,
                onFilterChange = onFilterChange,
                onSortChange = onSortChange,
                onClearCompleted = onClearCompleted,
                modifier = Modifier.padding(innerPadding),
            )
        }
    }
}
