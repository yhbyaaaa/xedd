package com.suishouji.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TodoDao {
    @Query("SELECT * FROM todo_table ORDER BY isCompleted ASC, createTime DESC")
    fun observeAll(): Flow<List<TodoEntity>>

    @Query("SELECT * FROM todo_table WHERE isCompleted = 1 ORDER BY createTime DESC")
    suspend fun getCompleted(): List<TodoEntity>

    @Insert
    suspend fun insert(todo: TodoEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restore(todo: TodoEntity)

    @Query("UPDATE todo_table SET isCompleted = :completed, updateTime = :updatedAt WHERE id = :id")
    suspend fun updateCompletion(id: Long, completed: Boolean, updatedAt: Long)

    @Query("UPDATE todo_table SET content = :content, updateTime = :updatedAt WHERE id = :id")
    suspend fun updateContent(id: Long, content: String, updatedAt: Long)

    @Query("DELETE FROM todo_table WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM todo_table WHERE isCompleted = 1")
    suspend fun deleteCompleted(): Int
}
