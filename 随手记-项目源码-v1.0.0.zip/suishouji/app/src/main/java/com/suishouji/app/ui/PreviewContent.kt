package com.suishouji.app.ui

import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.tooling.preview.Preview
import com.suishouji.app.data.TodoEntity
import com.suishouji.app.model.TodoFilter
import com.suishouji.app.model.TodoSort
import com.suishouji.app.ui.theme.SuishoujiTheme

@Composable
fun TodoAppPreviewContent(state: TodoUiState) {
    val snackbarHostState = remember { SnackbarHostState() }
    TodoAppScaffold(
        state = state,
        snackbarHostState = snackbarHostState,
        onAdd = {},
        onEdit = {},
        onToggle = {},
        onDelete = {},
        onFilterChange = {},
        onSortChange = {},
        onClearCompleted = {},
    )
}

private fun previewState(): TodoUiState {
    val now = System.currentTimeMillis()
    return TodoUiState(
        todos = listOf(
            TodoEntity(
                id = 1,
                content = "给阳台的绿萝浇水",
                createTime = now - 45 * 60_000L,
                updateTime = now - 45 * 60_000L,
            ),
            TodoEntity(
                id = 2,
                content = "把《人间草木》最后两章读完，顺手记下喜欢的句子。",
                createTime = now - 3 * 60 * 60_000L,
                updateTime = now - 3 * 60 * 60_000L,
            ),
            TodoEntity(
                id = 3,
                content = "预约周五下午的牙医",
                createTime = now - 25 * 60 * 60_000L,
                updateTime = now - 25 * 60 * 60_000L,
            ),
            TodoEntity(
                id = 4,
                content = "给妈妈回个电话",
                isCompleted = true,
                createTime = now - 5 * 60 * 60_000L,
                updateTime = now - 60 * 60_000L,
            ),
        ),
        filter = TodoFilter.ALL,
        sort = TodoSort.PENDING_FIRST,
        isLoading = false,
    )
}

@Composable
private fun PreviewFrame(state: TodoUiState) {
    SuishoujiTheme {
        TodoAppPreviewContent(state)
    }
}

@Preview(
    name = "随手记 · 首页",
    showBackground = true,
    widthDp = 412,
    heightDp = 915,
)
@Composable
private fun TodoHomePreview() {
    PreviewFrame(previewState())
}

@Preview(
    name = "随手记 · 空状态",
    showBackground = true,
    widthDp = 412,
    heightDp = 915,
)
@Composable
private fun TodoEmptyPreview() {
    PreviewFrame(
        TodoUiState(
            filter = TodoFilter.ALL,
            isLoading = false,
        ),
    )
}

@Preview(
    name = "随手记 · 深色",
    showBackground = true,
    widthDp = 412,
    heightDp = 915,
    uiMode = android.content.res.Configuration.UI_MODE_NIGHT_YES,
)
@Composable
private fun TodoDarkPreview() {
    SuishoujiTheme(darkTheme = true) {
        TodoAppPreviewContent(previewState())
    }
}
