package com.suishouji.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.suishouji.app.model.TodoFilter

@Composable
fun EmptyState(
    filter: TodoFilter,
    hasRecords: Boolean,
    onAdd: () -> Unit,
) {
    val title = when {
        !hasRecords -> "还没有记事"
        filter == TodoFilter.PENDING -> "待办清空了"
        filter == TodoFilter.COMPLETED -> "还没有完成项"
        else -> "清单是空的"
    }
    val body = when {
        !hasRecords -> "想到什么，就随手写下来。\n小事也值得被记住。"
        filter == TodoFilter.PENDING -> "今天的清单已经完成，\n给自己一点休息时间。"
        filter == TodoFilter.COMPLETED -> "完成一件小事后，\n它会安静地待在这里。"
        else -> "写下第一笔，\n让思绪有处安放。"
    }
    val cta = when {
        !hasRecords -> "记下第一件事"
        filter == TodoFilter.PENDING -> "再记一笔"
        else -> null
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 18.dp, bottom = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        EmptyIllustration()
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(7.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        if (cta != null) {
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onAdd,
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = cta,
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }
    }
}

@Composable
private fun EmptyIllustration() {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val surface = MaterialTheme.colorScheme.surface
    val line = MaterialTheme.colorScheme.outlineVariant
    val outline = MaterialTheme.colorScheme.outline

    Canvas(modifier = Modifier.size(width = 204.dp, height = 164.dp)) {
        val w = size.width
        val h = size.height
        val paperWidth = w * 0.42f
        val paperHeight = h * 0.62f
        val left = (w - paperWidth) / 2f
        val top = h * 0.16f

        drawCircle(
            color = primary.copy(alpha = 0.075f),
            radius = w * 0.31f,
            center = Offset(w * 0.5f, h * 0.53f),
        )

        rotate(degrees = -5f, pivot = Offset(w * 0.5f, h * 0.5f)) {
            drawRoundRect(
                color = Color.Black.copy(alpha = 0.055f),
                topLeft = Offset(left + 4.dp.toPx(), top + 6.dp.toPx()),
                size = Size(paperWidth, paperHeight),
                cornerRadius = CornerRadius(16.dp.toPx()),
            )
            drawRoundRect(
                color = surface,
                topLeft = Offset(left, top),
                size = Size(paperWidth, paperHeight),
                cornerRadius = CornerRadius(16.dp.toPx()),
            )
            drawRoundRect(
                color = line.copy(alpha = 0.9f),
                topLeft = Offset(left, top),
                size = Size(paperWidth, paperHeight),
                cornerRadius = CornerRadius(16.dp.toPx()),
                style = Stroke(width = 1.2.dp.toPx()),
            )

            val lineStart = left + paperWidth * 0.18f
            val lineWidth = paperWidth * 0.52f
            listOf(0.30f, 0.42f, 0.54f).forEachIndexed { index, yFraction ->
                drawRoundRect(
                    color = line.copy(alpha = if (index == 0) 0.9f else 0.62f),
                    topLeft = Offset(lineStart, top + paperHeight * yFraction),
                    size = Size(
                        width = lineWidth * if (index == 2) 0.68f else 1f,
                        height = 3.dp.toPx(),
                    ),
                    cornerRadius = CornerRadius(2.dp.toPx()),
                )
            }
        }

        val badgeCenter = Offset(w * 0.68f, h * 0.68f)
        val badgeRadius = w * 0.086f
        drawCircle(
            color = surface.copy(alpha = 0.92f),
            radius = badgeRadius + 2.dp.toPx(),
            center = badgeCenter,
        )
        drawCircle(
            color = secondary,
            radius = badgeRadius,
            center = badgeCenter,
        )
        val check = Path().apply {
            moveTo(badgeCenter.x - badgeRadius * 0.48f, badgeCenter.y + badgeRadius * 0.02f)
            lineTo(badgeCenter.x - badgeRadius * 0.08f, badgeCenter.y + badgeRadius * 0.42f)
            lineTo(badgeCenter.x + badgeRadius * 0.52f, badgeCenter.y - badgeRadius * 0.40f)
        }
        drawPath(
            path = check,
            color = surface,
            style = Stroke(
                width = 3.4.dp.toPx(),
                cap = StrokeCap.Round,
                join = StrokeJoin.Round,
            ),
        )

        drawCircle(
            color = primary.copy(alpha = 0.35f),
            radius = 3.2.dp.toPx(),
            center = Offset(w * 0.23f, h * 0.30f),
        )
        drawCircle(
            color = secondary.copy(alpha = 0.45f),
            radius = 2.2.dp.toPx(),
            center = Offset(w * 0.80f, h * 0.26f),
        )
        drawCircle(
            color = primary.copy(alpha = 0.24f),
            radius = 2.6.dp.toPx(),
            center = Offset(w * 0.21f, h * 0.76f),
        )
        drawCircle(
            color = outline.copy(alpha = 0.28f),
            radius = 1.8.dp.toPx(),
            center = Offset(w * 0.83f, h * 0.84f),
        )
    }
}

@Composable
fun ClearCompletedDialog(
    count: Int,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(26.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        icon = {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(MaterialTheme.colorScheme.errorContainer, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.size(21.dp),
                )
            }
        },
        title = {
            Text(
                text = "清空已完成？",
                style = MaterialTheme.typography.headlineSmall,
            )
        },
        text = {
            Text(
                text = "将删除 $count 件已完成事项。\n如果改变主意，可以在提示条中撤销。",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = onConfirm) {
                Text(
                    text = "清空",
                    color = MaterialTheme.colorScheme.error,
                )
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text(
                    text = "取消",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
    )
}
