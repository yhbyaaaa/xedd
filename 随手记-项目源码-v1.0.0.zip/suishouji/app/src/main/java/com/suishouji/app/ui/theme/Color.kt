package com.suishouji.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light — warm paper, terracotta ink, a quiet olive accent.
val Terracotta = Color(0xFFD25C3F)
val OnTerracotta = Color(0xFFFFFFFF)
val TerracottaContainer = Color(0xFFF8DDD3)
val OnTerracottaContainer = Color(0xFF4B170C)
val Olive = Color(0xFF6E805C)
val OnOlive = Color(0xFFFFFFFF)
val OliveContainer = Color(0xFFE5EBD8)
val OnOliveContainer = Color(0xFF263018)
val Walnut = Color(0xFF7A6A55)
val OnWalnut = Color(0xFFFFFFFF)
val WalnutContainer = Color(0xFFF0E5D4)
val OnWalnutContainer = Color(0xFF2B2114)

val Paper = Color(0xFFF8F4EC)
val PaperOverlay = Color(0xFFFFFCF7)
val Ink = Color(0xFF25231E)
val InkSoft = Color(0xFF6A665D)
val Line = Color(0xFFDED7C9)
val PaperDeep = Color(0xFFEFE8DC)
val SwipeRed = Color(0xFFB3261E)
val SwipeRedContainer = Color(0xFFFFDAD6)

// Dark — warm charcoal instead of pure black.
val TerracottaDark = Color(0xFFFFB4A2)
val OnTerracottaDark = Color(0xFF5F1A0B)
val TerracottaContainerDark = Color(0xFF7D2D1B)
val OnTerracottaContainerDark = Color(0xFFFFDAD1)
val OliveDark = Color(0xFFB9C9A4)
val OnOliveDark = Color(0xFF25321A)
val OliveContainerDark = Color(0xFF3A4A2D)
val OnOliveContainerDark = Color(0xFFD5E5C0)
val WalnutDark = Color(0xFFDDC3A2)
val OnWalnutDark = Color(0xFF3E2E1C)
val WalnutContainerDark = Color(0xFF57452F)
val OnWalnutContainerDark = Color(0xFFF8E1C3)

val Charcoal = Color(0xFF171511)
val CharcoalSurface = Color(0xFF201D18)
val CharcoalElevated = Color(0xFF2A2620)
val Cream = Color(0xFFEAE3D7)
val CreamSoft = Color(0xFFCBC4B7)
val DarkLine = Color(0xFF4D473E)
val SwipeRedDark = Color(0xFFFFB4AB)
val SwipeRedContainerDark = Color(0xFF93000A)
