package com.suishouji.app.model

import com.suishouji.app.data.TodoEntity

enum class TodoSort(
    val label: String,
    val hint: String,
) {
    PENDING_FIRST(
        label = "未完成优先",
        hint = "待办在前，新记录在后",
    ),
    NEWEST_FIRST(
        label = "最新创建",
        hint = "最近写下的排在前面",
    ),
    OLDEST_FIRST(
        label = "最早创建",
        hint = "先写的排在前面",
    );

    fun sort(items: List<TodoEntity>): List<TodoEntity> = when (this) {
        PENDING_FIRST -> items.sortedWith(
            compareBy<TodoEntity> { it.isCompleted }
                .thenByDescending { it.createTime }
                .thenByDescending { it.id },
        )

        NEWEST_FIRST -> items.sortedWith(
            compareByDescending<TodoEntity> { it.createTime }
                .thenByDescending { it.id },
        )

        OLDEST_FIRST -> items.sortedWith(
            compareBy<TodoEntity> { it.createTime }
                .thenBy { it.id },
        )
    }
}

enum class TodoFilter(val label: String) {
    ALL("全部"),
    PENDING("待办"),
    COMPLETED("已完成");

    fun filter(items: List<TodoEntity>): List<TodoEntity> = when (this) {
        ALL -> items
        PENDING -> items.filterNot { it.isCompleted }
        COMPLETED -> items.filter { it.isCompleted }
    }
}
