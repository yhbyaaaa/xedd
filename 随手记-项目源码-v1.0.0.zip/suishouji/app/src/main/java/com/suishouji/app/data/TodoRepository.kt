package com.suishouji.app.data

import com.suishouji.app.model.TodoSort
import kotlinx.coroutines.flow.Flow

class TodoRepository(
    private val todoDao: TodoDao,
    private val settingsRepository: SettingsRepository,
) {
    val todos: Flow<List<TodoEntity>> = todoDao.observeAll()

    fun loadSort(): TodoSort = settingsRepository.loadSort()

    fun saveSort(sort: TodoSort) = settingsRepository.saveSort(sort)

    suspend fun add(content: String): Long {
        val now = System.currentTimeMillis()
        return todoDao.insert(
            TodoEntity(
                content = content,
                createTime = now,
                updateTime = now,
            ),
        )
    }

    suspend fun updateContent(id: Long, content: String) {
        todoDao.updateContent(id, content, System.currentTimeMillis())
    }

    suspend fun setCompleted(id: Long, completed: Boolean) {
        todoDao.updateCompletion(id, completed, System.currentTimeMillis())
    }

    suspend fun delete(todo: TodoEntity) {
        todoDao.deleteById(todo.id)
    }

    suspend fun restore(todo: TodoEntity) {
        todoDao.restore(todo)
    }

    suspend fun restoreAll(todos: List<TodoEntity>) {
        todos.forEach { todoDao.restore(it) }
    }

    suspend fun clearCompleted(): List<TodoEntity> {
        val completed = todoDao.getCompleted()
        if (completed.isNotEmpty()) {
            todoDao.deleteCompleted()
        }
        return completed
    }
}
