package com.suishouji.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.suishouji.app.SuishoujiApplication
import com.suishouji.app.data.TodoEntity
import com.suishouji.app.model.TodoFilter
import com.suishouji.app.model.TodoSort
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TodoUiState(
    val todos: List<TodoEntity> = emptyList(),
    val filter: TodoFilter = TodoFilter.ALL,
    val sort: TodoSort = TodoSort.PENDING_FIRST,
    val isLoading: Boolean = true,
) {
    val pendingTodos: List<TodoEntity> get() = todos.filterNot { it.isCompleted }
    val completedTodos: List<TodoEntity> get() = todos.filter { it.isCompleted }
    val pendingCount: Int get() = pendingTodos.size
    val completedCount: Int get() = completedTodos.size
    val totalCount: Int get() = todos.size
    val progress: Float
        get() = if (totalCount == 0) 0f else completedCount.toFloat() / totalCount
    val visibleTodos: List<TodoEntity> get() = filter.filter(todos)
}

sealed interface TodoEvent {
    data class Deleted(val todo: TodoEntity) : TodoEvent
    data class CompletedCleared(val todos: List<TodoEntity>) : TodoEvent
    data class Saved(val isNew: Boolean) : TodoEvent
    data class Failed(val message: String) : TodoEvent
}

class TodoViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as SuishoujiApplication).repository

    private val _filter = MutableStateFlow(TodoFilter.ALL)
    private val _sort = MutableStateFlow(repository.loadSort())
    private val eventChannel = Channel<TodoEvent>(Channel.BUFFERED)

    val events = eventChannel.receiveAsFlow()

    val uiState: StateFlow<TodoUiState> = combine(
        repository.todos,
        _filter,
        _sort,
    ) { todos, filter, sort ->
        TodoUiState(
            todos = sort.sort(todos),
            filter = filter,
            sort = sort,
            isLoading = false,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TodoUiState(
            sort = _sort.value,
            isLoading = true,
        ),
    )

    fun setFilter(filter: TodoFilter) {
        _filter.value = filter
    }

    fun setSort(sort: TodoSort) {
        if (_sort.value == sort) return
        _sort.value = sort
        repository.saveSort(sort)
    }

    fun saveTodo(content: String, existing: TodoEntity?) {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            runCatching {
                if (existing == null) {
                    repository.add(trimmed)
                } else {
                    repository.updateContent(existing.id, trimmed)
                }
            }.onSuccess {
                eventChannel.send(TodoEvent.Saved(isNew = existing == null))
            }.onFailure {
                eventChannel.send(TodoEvent.Failed("保存失败，请再试一次"))
            }
        }
    }

    fun toggleCompleted(todo: TodoEntity) {
        viewModelScope.launch {
            runCatching {
                repository.setCompleted(todo.id, !todo.isCompleted)
            }.onFailure {
                eventChannel.send(TodoEvent.Failed("状态更新失败"))
            }
        }
    }

    fun deleteTodo(todo: TodoEntity) {
        viewModelScope.launch {
            runCatching {
                repository.delete(todo)
            }.onSuccess {
                eventChannel.send(TodoEvent.Deleted(todo))
            }.onFailure {
                eventChannel.send(TodoEvent.Failed("删除失败，请再试一次"))
            }
        }
    }

    fun undoDelete(todo: TodoEntity) {
        viewModelScope.launch {
            runCatching { repository.restore(todo) }
                .onFailure { eventChannel.send(TodoEvent.Failed("撤销失败")) }
        }
    }

    fun clearCompleted() {
        val completed = uiState.value.completedTodos
        if (completed.isEmpty()) return

        viewModelScope.launch {
            runCatching { repository.clearCompleted() }
                .onSuccess { eventChannel.send(TodoEvent.CompletedCleared(completed)) }
                .onFailure { eventChannel.send(TodoEvent.Failed("清空失败，请再试一次")) }
        }
    }

    fun undoClearCompleted(todos: List<TodoEntity>) {
        viewModelScope.launch {
            runCatching { repository.restoreAll(todos) }
                .onFailure { eventChannel.send(TodoEvent.Failed("撤销失败")) }
        }
    }
}
