package com.suishouji.app

import android.app.Application
import com.suishouji.app.data.AppDatabase
import com.suishouji.app.data.SettingsRepository
import com.suishouji.app.data.TodoRepository

class SuishoujiApplication : Application() {
    val repository: TodoRepository by lazy {
        val database = AppDatabase.getInstance(this)
        TodoRepository(
            todoDao = database.todoDao(),
            settingsRepository = SettingsRepository(this),
        )
    }
}
