package com.suishouji.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.suishouji.app.ui.TodoApp
import com.suishouji.app.ui.theme.SuishoujiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SuishoujiTheme {
                TodoApp()
            }
        }
    }
}
