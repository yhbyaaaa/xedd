package com.suishouji.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Terracotta,
    onPrimary = OnTerracotta,
    primaryContainer = TerracottaContainer,
    onPrimaryContainer = OnTerracottaContainer,
    secondary = Olive,
    onSecondary = OnOlive,
    secondaryContainer = OliveContainer,
    onSecondaryContainer = OnOliveContainer,
    tertiary = Walnut,
    onTertiary = OnWalnut,
    tertiaryContainer = WalnutContainer,
    onTertiaryContainer = OnWalnutContainer,
    background = Paper,
    onBackground = Ink,
    surface = PaperOverlay,
    onSurface = Ink,
    surfaceVariant = PaperDeep,
    onSurfaceVariant = InkSoft,
    surfaceContainerLowest = PaperOverlay,
    surfaceContainerLow = ColorTokens.SurfaceLow,
    surfaceContainer = ColorTokens.Surface,
    surfaceContainerHigh = ColorTokens.SurfaceHigh,
    surfaceContainerHighest = PaperDeep,
    outline = ColorTokens.Outline,
    outlineVariant = Line,
    error = SwipeRed,
    errorContainer = SwipeRedContainer,
    onErrorContainer = ColorTokens.OnSwipeRedContainer,
    scrim = ColorTokens.Scrim,
)

private val DarkColors = darkColorScheme(
    primary = TerracottaDark,
    onPrimary = OnTerracottaDark,
    primaryContainer = TerracottaContainerDark,
    onPrimaryContainer = OnTerracottaContainerDark,
    secondary = OliveDark,
    onSecondary = OnOliveDark,
    secondaryContainer = OliveContainerDark,
    onSecondaryContainer = OnOliveContainerDark,
    tertiary = WalnutDark,
    onTertiary = OnWalnutDark,
    tertiaryContainer = WalnutContainerDark,
    onTertiaryContainer = OnWalnutContainerDark,
    background = Charcoal,
    onBackground = Cream,
    surface = CharcoalSurface,
    onSurface = Cream,
    surfaceVariant = CharcoalElevated,
    onSurfaceVariant = CreamSoft,
    surfaceContainerLowest = Charcoal,
    surfaceContainerLow = CharcoalSurface,
    surfaceContainer = ColorTokens.DarkSurface,
    surfaceContainerHigh = ColorTokens.DarkSurfaceHigh,
    surfaceContainerHighest = CharcoalElevated,
    outline = ColorTokens.DarkOutline,
    outlineVariant = DarkLine,
    error = SwipeRedDark,
    errorContainer = SwipeRedContainerDark,
    onErrorContainer = ColorTokens.OnSwipeRedDark,
    scrim = ColorTokens.DarkScrim,
)

private object ColorTokens {
    val SurfaceLow = androidx.compose.ui.graphics.Color(0xFFFBF7F0)
    val Surface = androidx.compose.ui.graphics.Color(0xFFF6F0E6)
    val SurfaceHigh = androidx.compose.ui.graphics.Color(0xFFF1EADF)
    val Outline = androidx.compose.ui.graphics.Color(0xFF8E8677)
    val OnSwipeRedContainer = androidx.compose.ui.graphics.Color(0xFF410002)
    val DarkSurface = androidx.compose.ui.graphics.Color(0xFF25211C)
    val DarkSurfaceHigh = androidx.compose.ui.graphics.Color(0xFF302B24)
    val DarkOutline = androidx.compose.ui.graphics.Color(0xFF999084)
    val OnSwipeRedDark = androidx.compose.ui.graphics.Color(0xFFFFDAD6)
    val Scrim = androidx.compose.ui.graphics.Color(0xFF000000)
    val DarkScrim = androidx.compose.ui.graphics.Color(0xFF000000)
}

private val SuishoujiShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

@Composable
fun SuishoujiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = SuishoujiTypography,
        shapes = SuishoujiShapes,
        content = content,
    )
}
