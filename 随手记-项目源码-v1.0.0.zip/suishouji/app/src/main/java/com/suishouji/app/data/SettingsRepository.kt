package com.suishouji.app.data

import android.content.Context
import com.suishouji.app.model.TodoSort

class SettingsRepository(context: Context) {
    private val preferences = context.getSharedPreferences("suishouji_settings", Context.MODE_PRIVATE)

    fun loadSort(): TodoSort {
        val stored = preferences.getString(KEY_SORT, null) ?: return TodoSort.PENDING_FIRST
        return TodoSort.entries.firstOrNull { it.name == stored } ?: TodoSort.PENDING_FIRST
    }

    fun saveSort(sort: TodoSort) {
        preferences.edit().putString(KEY_SORT, sort.name).apply()
    }

    private companion object {
        const val KEY_SORT = "todo_sort"
    }
}
